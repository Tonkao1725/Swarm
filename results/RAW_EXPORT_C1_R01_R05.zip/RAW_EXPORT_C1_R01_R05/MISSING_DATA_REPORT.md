# Missing Data Report

| Metric | Status | Exact source file(s) | Note |
|---|---|---|---|
| A. Effective termination time | AVAILABLE | swarm_events.csv / ROBOT_DEPLETED | Latest depletion event per Run. |
| B. Per-Scout depletion time | AVAILABLE | swarm_events.csv / ROBOT_DEPLETED | Event timestamp per Scout. |
| C. Robot Internal Energy vs time | AVAILABLE | robot_energy_timeline.csv | Per-Scout timeline. |
| D. Nest Energy vs time | AVAILABLE | nest_energy_timeline.csv | Event-level timeline. |
| E. Nest withdrawal events | AVAILABLE | swarm_events.csv, nest_energy_timeline.csv | Event-level. |
| F. Delivery events | AVAILABLE | swarm_events.csv, nest_energy_timeline.csv | Event-level. |
| G. Resource A/B/C detections | AVAILABLE | swarm_events.csv / RESOURCE_LIGHT_DETECTED | Resource ID in detail field. |
| H. Resource collection start/end | PARTIAL | swarm_events.csv / HARVEST_ACTIVE, HARVEST_COMPLETE | Start is repeated activity rather than one transition event. |
| I. Resource collection duration | AVAILABLE | swarm_events.csv / HARVEST_COMPLETE | Completion detail includes elapsed seconds. |
| J. Return attempt start | AVAILABLE | swarm_events.csv / RETURN_HOME_START | Event-level. |
| K. Nest reached | AVAILABLE | swarm_events.csv / NEST_REACHED | Physical arrival confirmation. |
| L. Return success/failure | PARTIAL | swarm_events.csv, robot_energy_timeline.csv | Success is direct; unsuccessful return inferred from started return followed by depletion/no Nest reached. |
| M. Full trajectory | AVAILABLE | swarm_trajectory.csv, trajectory.csv | Per-step data retained in full, including post-depletion rows. |
| N. Distance travelled | AVAILABLE | swarm_trajectory.csv | Cumulative/trip distance columns. |
| O. Behavior/state duration | PARTIAL | swarm_trajectory.csv / phase | EXPLORE, HARVEST, RETURN_HOME, DELIVER, DEPLETED exist; no separate APPROACH_RESOURCE or RECHARGE phase. |
| P. Collision/recovery events | AVAILABLE | swarm_events.csv | Contact/recovery events. |
| Q. Sensor values | PARTIAL | swarm_trajectory.csv | Local sensor fields are available there; no distinct sensor timeline CSV exists. |
| R. Cycle boundaries | AVAILABLE | swarm_events.csv, swarm_trip_summary.csv | SCOUT_START/NEXT_CYCLE_START and trip summary. |
