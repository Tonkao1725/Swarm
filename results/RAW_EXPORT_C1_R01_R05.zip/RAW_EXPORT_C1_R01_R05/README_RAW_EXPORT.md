# C1 R01–R05 Raw Data Export

This package is a lossless copy of every file inside the five specified original run folders. No simulation was rerun; no rows, timestamps, columns, state/action names, or numeric values were transformed. Derived summaries are retained but marked `DERIVED` in `FILE_MANIFEST.csv`.

## Source folders and expected seeds

- R01: `E:\SwarmSimulate\results\final_c1_canonical_20seed_energy_v1_20260820\R01_seed82784102_3600s` (seed `82784102`)
- R02: `E:\SwarmSimulate\results\c1_advisor_preview_parallel_r02_r04_20260820\R02_seed98386804_3600s` (seed `98386804`)
- R03: `E:\SwarmSimulate\results\c1_advisor_preview_parallel_r02_r04_20260820\R03_seed358777504_3600s` (seed `358777504`)
- R04: `E:\SwarmSimulate\results\c1_advisor_preview_parallel_r02_r04_20260820\R04_seed385197017_3600s` (seed `385197017`)
- R05: `E:\SwarmSimulate\results\c1_advisor_preview_r05_20260820\R05_seed413997162_3600s` (seed `413997162`)

## Major data available

- Per-step Scout trajectory/state/action data: `swarm_trajectory.csv`
- Simulator trajectory/movement/wheel/encoder/odometry logs: `trajectory.csv`, `movement.csv`, `wheel.csv`, `encoder.csv`, `odometry.csv`
- Event-level resource, return, Nest, delivery, depletion and recovery data: `swarm_events.csv`
- Robot internal-energy timeline: `robot_energy_timeline.csv`
- Nest energy timeline: `nest_energy_timeline.csv`
- Configuration and source snapshots: `metadata.json`, `source_snapshot/`
- Console diagnostics: `console_stdout.txt`, `console_stderr.txt`

Exact behavioral time budgets can be independently reconstructed from `swarm_trajectory.csv` phase samples, with the caveat that no separate `APPROACH_RESOURCE` phase is logged. Sensor observations are present only to the extent embedded in the per-step trajectory fields; no separate raw ToF/Solar/RSSI sensor timeline file was generated.

Seed verification: all metadata seeds match the requested mapping.
